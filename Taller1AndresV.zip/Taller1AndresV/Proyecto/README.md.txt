# Taller Práctico #1
## Solución de IA Generativa para EcoMarket
### Fases 1 y 2: Selección del modelo y evaluación crítica
**Universidad Icesi · Inteligencia Artificial Generativa**
**Andrés Velásquez M.**

---

## Contexto

EcoMarket es una empresa de e-commerce de productos sostenibles en crecimiento acelerado. Su área de soporte recibe miles de consultas diarias por chat, correo y redes sociales. El 80% son repetitivas (estado de pedido, devoluciones, características de producto) y el 20% restante requiere atención especializada con empatía humana (quejas, problemas técnicos, sugerencias). El tiempo de respuesta actual es de 24 horas, lo que afecta directamente la satisfacción del cliente. El objetivo es reducir ese tiempo y mejorar la calidad de las respuestas mediante IA generativa.

---

## FASE 1: Selección y Justificación del Modelo de IA

### 1.1 Comparación de categorías de modelos

Se evalúan las principales categorías de soluciones de IA generativa aplicables al problema de EcoMarket:

| Categoría | Costo | Escalabilidad | Integración | Calidad de respuesta |
|---|---|---|---|---|
| LLM general vía API (GPT-4, Claude, Gemini) | Medio (pago por uso) | Alta (gestionada por proveedor) | Muy fácil (REST API) | Muy alta |
| LLM open-source (LLaMA, Mistral) | Alto inicial (infraestructura propia) | Media (requiere MLOps) | Media | Alta si bien configurado |
| LLM open-source vía API gratuita (Groq) | Gratis (tier gratuito) | Alta (gestionada por Groq) | Muy fácil (REST API) | Alta |
| Chatbot de reglas + NLP básico | Bajo | Alta | Fácil | Baja (respuestas rígidas) |
| Solución híbrida LLM + RAG | Medio | Alta | Media-Alta | Muy alta (datos propios + LLM) |

### 1.2 Comparación de modelos LLM específicos

Dentro de la categoría de LLMs, se comparan las opciones más relevantes:

| Modelo | Proveedor | Costo | Contexto | Observaciones |
|---|---|---|---|---|
| GPT-4o | OpenAI | Pago (~$5/1M tokens) | 128K tokens | Excelente calidad, requiere pago |
| Claude 3.5 Sonnet | Anthropic | Pago (~$3/1M tokens) | 200K tokens | Muy bueno en razonamiento complejo |
| Gemini 1.5 Pro | Google | Pago (~$3.5/1M tokens) | 1M tokens | Gran contexto, requiere pago |
| LLaMA 3 70B vía Groq | Meta / Groq | Gratuito (tier free) | 8K tokens | Open-source, API gratuita, buen rendimiento general |
| Mistral 7B vía Groq | Mistral / Groq | Gratuito (tier free) | 32K tokens | Ligero y rápido, API gratuita |

### 1.3 Decisión del modelo

Para el contexto académico de este taller, el criterio prioritario es la accesibilidad sin costo. Los modelos comerciales (GPT-4o, Claude, Gemini) ofrecen mayor calidad, pero requieren pago por uso. LLaMA 3 70B disponible vía Groq ofrece un tier gratuito con rendimiento suficiente para resolver el 80% de consultas repetitivas de EcoMarket, que son precisamente las más estructuradas y directas. Para el 20% de casos complejos, la solución de todas formas los escala a agentes humanos, por lo que el modelo no necesita el nivel de razonamiento de un GPT-4o.

> **Decisión:** Se selecciona LLaMA 3 70B vía la API gratuita de Groq como modelo base para este prototipo, por ser la opción open-source gratuita de mayor rendimiento disponible actualmente. En un entorno de producción real, se recomendaría migrar a una solución híbrida con Claude 3.5 Sonnet o GPT-4o + RAG conectado a la base de datos de EcoMarket, lo que maximizará la precisión en consultas de pedidos específicos.

### 1.4 Arquitectura propuesta

La arquitectura sigue el principio de los modelos Transformer decoder-only, donde el modelo recibe como input el prompt con el contexto del negocio y genera tokens de respuesta secuencialmente (Avila, 2025a). Se estructura en cinco capas:

| Capa | Componente | Función |
|---|---|---|
| 1 | Clasificador de intenciones | Determina si la consulta es simple (80%) o compleja (20%) |
| 2 | Prompt con contexto | Inyecta información del pedido o producto en el prompt |
| 3 | LLaMA 3 70B vía Groq | Genera la respuesta en lenguaje natural con tono empático |
| 4 | Filtro de calidad | Verifica que la respuesta no contenga información inventada |
| 5 | Escalada a agente humano | Recibe el 20% de casos complejos con el historial de conversación |

### 1.5 Justificación por criterios

**Costo:** El tier gratuito de Groq elimina cualquier barrera económica para este prototipo. En producción, el modelo pay-per-use de APIs comerciales sigue siendo más económico que mantener infraestructura GPU propia para correr un LLM open-source.

**Escalabilidad:** La API de Groq gestiona la infraestructura automáticamente. No se requiere configurar servidores ni preocuparse por picos de demanda en temporadas altas.

**Facilidad de integración:** La API REST de Groq es compatible con el estándar de OpenAI, lo que facilita la integración con los canales existentes de EcoMarket y permite migrar a otro proveedor en el futuro sin reescribir el código.

**Calidad de respuesta:** LLaMA 3 70B comprende el contexto de la conversación gracias al mecanismo de multi-headed self-attention de la arquitectura Transformer (Vaswani et al., 2017), lo que le permite generar respuestas coherentes y contextualizadas para el 80% de consultas repetitivas de EcoMarket.

---

## FASE 2: Evaluación de Fortalezas, Limitaciones y Riesgos Éticos

### 2.1 Fortalezas

| Fortaleza | Descripción | Impacto concreto en EcoMarket |
|---|---|---|
| Disponibilidad 24/7 | Opera sin interrupciones | Elimina esperas fuera de horario laboral |
| Tiempo de respuesta inmediato | Responde en segundos | Reduce el tiempo de 24 h a menos de 1 minuto |
| Manejo de volumen | Escala automáticamente | Sin cuello de botella en fechas especiales |
| Consistencia | Respuestas basadas en políticas oficiales | Reduce errores por fatiga o desconocimiento del agente |
| Liberación de agentes | Automatiza el 80% de consultas repetitivas | Los agentes se enfocan en el 20% de casos que realmente requieren atención humana |

### 2.2 Limitaciones

| Limitación | Descripción | Estrategia de mitigación |
|---|---|---|
| Sin empatía real | No puede gestionar el 20% de casos complejos que requieren comprensión emocional genuina | Escalada a agente humano cuando se detectan palabras clave de malestar |
| Dependencia de la calidad del prompt | Si el prompt no incluye la información correcta del pedido, la respuesta será incorrecta | Recuperar los datos de la base de datos antes de construir el prompt |
| Context window limitado (8K tokens en LLaMA 3) | Conversaciones muy largas pueden perder contexto | Resumir el historial de conversación antes de enviarlo al modelo |
| Sin acceso en tiempo real a la base de datos | El modelo no consulta directamente la base de datos de EcoMarket | El sistema debe inyectar la información relevante del pedido en cada prompt |

### 2.3 Riesgos éticos

**Alucinaciones:** El modelo puede generar información falsa si no tiene datos concretos del pedido. Por ejemplo, inventar una fecha de entrega que no existe. Este es el riesgo más crítico porque afecta directamente la confianza del cliente. Mitigación: el prompt debe incluir siempre la información real del pedido y una instrucción explícita de no inventar datos si no los tiene disponibles.

**Sesgo algorítmico:** Los datos de entrenamiento de LLaMA 3 pueden contener sesgos que lleven al modelo a dar respuestas de diferente calidad según el estilo de escritura del cliente. Mitigación: auditar periódicamente una muestra de respuestas generadas para detectar patrones de trato diferencial.

**Privacidad de datos:** Al incluir información del cliente (nombre, dirección, historial de compras) en los prompts enviados a la API de Groq, esos datos son procesados en servidores externos. Mitigación: revisar la política de privacidad de Groq, evitar incluir datos sensibles innecesarios en el prompt, y en producción considerar un proveedor con acuerdo DPA firmado.

**Impacto laboral:** Automatizar el 80% de consultas puede percibirse como una amenaza para los agentes de soporte actuales. El objetivo de esta solución no es reemplazarlos, sino redirigir su tiempo hacia casos que generan mayor valor. Recomendación: comunicar claramente este objetivo al equipo y capacitarlos en el uso de las nuevas herramientas para que trabajen junto al sistema de IA.

**Falta de transparencia:** El cliente tiene derecho a saber si está interactuando con una IA o con un humano. No indicarlo genera desconfianza cuando el cliente lo descubre. Mitigación: el asistente debe identificarse como IA al inicio de cada conversación y ofrecer siempre la opción de hablar con un agente humano.

### Tabla resumen de riesgos

| Riesgo | Probabilidad | Impacto | Prioridad de atención |
|---|---|---|---|
| Alucinaciones | Media | Alto | 1 — Crítica |
| Privacidad de datos | Media | Alto | 2 — Crítica |
| Impacto laboral | Alta | Medio | 3 — Alta |
| Sesgo algorítmico | Baja | Medio | 4 — Media |
| Falta de transparencia | Baja | Alto | 5 — Media |

---

## Referencias

Avila, D. (2025a). *Arquitectura de Transformers* [Presentación de diapositivas]. Universidad Icesi.

Avila, D. (2025b). *Gen AI & LLMs* [Presentación de diapositivas]. Universidad Icesi.

Avila, D. (2025c). *Prompt Engineering* [Presentación de diapositivas]. Universidad Icesi.

Avila, D. (2025d). *Lab: Prompt Engineering* [Presentación de diapositivas]. Universidad Icesi.

Coursera / DeepLearning.AI. (s.f.). *Generative AI with Large Language Models*. https://www.coursera.org/programs/sobma/learn/generative-ai-with-llms

IBM. (s.f.). *What is generative AI?* https://www.ibm.com/topics/generative-ai

Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, J., Jones, L., Gomez, A. N., Kaiser, L., & Polosukhin, I. (2017). *Attention is all you need*. arXiv. https://arxiv.org/abs/1706.03762